import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {
        Aluno aluno = new Aluno();

        aluno.setNome("Lucas Amorim");
        aluno.setIdade(20);
        aluno.setCurso("Análise e Desenvolvimento de Sistemas");

        System.out.println(aluno.getNome());
    }
}